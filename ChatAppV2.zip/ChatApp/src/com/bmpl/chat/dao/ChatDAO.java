package com.bmpl.chat.dao;

import java.sql.Connection;
import static com.bmpl.chat.utils.Utilities.getValue;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ChatDAO {
	
	public static Connection createConnection() throws ClassNotFoundException, SQLException {
		Class.forName(getValue("DRIVER"));
		
		final String CONNECTION_STRING = getValue("CONNECTION_STRING");
		final String USER_ID = getValue("USERID");
		final String PASSWORD = getValue("PASSWORD");
		
		Connection con = DriverManager.getConnection(CONNECTION_STRING, USER_ID, PASSWORD);
		if(con != null) {
			System.out.println("Connection created successfully...");
			//con.close();
		}
		
		return con;
	}
//	public static void main(String[] args) throws ClassNotFoundException, SQLException {
//		ChatDAO dao = new ChatDAO();
//		dao.createConnection();
//	}
}
