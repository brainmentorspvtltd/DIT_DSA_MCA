package com.bmpl.chat.views;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.bmpl.chat.networking.Client;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.UnknownHostException;

public class ChatView {

	private JFrame frame;
	private JTextField textField;
	private JTextArea textArea;
	
	private Client client;
	
	public ChatView() throws UnknownHostException, IOException {
		textArea = new JTextArea();
		client = new Client(textArea);
		frame = new JFrame();
		frame.setBounds(100, 100, 945, 614);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 24));
		textArea.setBounds(10, 11, 900, 447);
		frame.getContentPane().add(textArea);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 28));
		textField.setBounds(10, 469, 668, 75);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Send Message");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
		btnNewButton.setBounds(696, 469, 214, 75);
		frame.getContentPane().add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				sendMsg();
			}
		});
	}
	
	private void sendMsg() {
		String msg = textField.getText();
		try {
			client.sendMsg(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws UnknownHostException, IOException {
		ChatView window = new ChatView();
		window.frame.setVisible(true);
	}
}
