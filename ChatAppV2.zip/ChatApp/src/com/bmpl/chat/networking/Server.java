package com.bmpl.chat.networking;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import static com.bmpl.chat.utils.Utilities.getValue;

public class Server {
	ServerSocket serverSocket;
	ArrayList<ServerWorker> workers = new ArrayList<>();
//	public Server() throws IOException {
//		int PORT = Integer.parseInt(getValue("PORT"));
//		serverSocket = new ServerSocket(PORT);
//		System.out.println("Server started and waiting for client...");
//		Socket socket = serverSocket.accept();	// accepts the client - handshaking
//		System.out.println("Client Arrived");
//		InputStream in = socket.getInputStream();	// read bytes from network
//		byte arr[] = in.readAllBytes();
//		String str = new String(arr);
//		System.out.println("Client : " + str);
//		in.close();
//		socket.close();
//	}
	
	public Server() throws IOException {
		int PORT = Integer.parseInt(getValue("PORT"));
		serverSocket = new ServerSocket(PORT);
		System.out.println("Server started and waiting for client...");
		handleClientReq();
	}
	
	public void handleClientReq() throws IOException {
		while(true) {
			Socket socket = serverSocket.accept();
			System.out.println("New Client Connected");
			ServerWorker serverworker = new ServerWorker(socket, this);
			workers.add(serverworker);
			serverworker.start();
		}
	}
	
	public static void main(String[] args) throws IOException {
		Server server = new Server();
	}
}
