package com.bmpl.chat.networking;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

//Worker = Thread
//Worker needs a job to be done
//Step 1 - create thread/worker
//Step 2 - assign a job to thread/worker
//Step 3 - thread will start doing its job
public class ServerWorker extends Thread {
	
	private Socket clientSocket;
	private InputStream in;
	private OutputStream os;
	private Server server;
	
	public ServerWorker(Socket clientSocket, Server server) throws IOException {
		this.clientSocket = clientSocket;
		in = clientSocket.getInputStream();
		os = clientSocket.getOutputStream();
		this.server = server;
	}

//	@Override
//	public void run() {
//		// Logic that worker will execute
//		for(int i = 1; i <= 5; i++) {
//			System.out.println("I is : " + i + "," + Thread.currentThread());
//			try {
//				Thread.sleep(100);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//	}
	
	@Override
	public void run() {
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line;
		while(true) {
			try {
				//System.out.println("Thread Started...");
				line = br.readLine();
				System.out.println("Server Line : " + line);
				if(line.equals("quit")) {
					break;
				}
				for(ServerWorker sworker : server.workers) {
					sworker.os.write((line + "\n").getBytes());
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				break;
			}
			finally {
				System.out.println("Closing all connections...");
				try {
					if(br != null) {
						br.close();
					}
					if(in != null) {
						in.close();
					}
					if(os != null) {
						os.close();
					}
					if(clientSocket != null) {
						clientSocket.close();
					}
				}
				catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				
			}
		}
	}
	
//	public static void main(String[] args) {
//		ServerWorker job = new ServerWorker();
//		Thread worker = new Thread(job);
//		worker.start();
//		// start method will call run() inside ServerWorker
//		
//		for(int i = 1; i <= 5; i++) {
//			System.out.println("Main is : " + i + "," + Thread.currentThread());
//		}
//	}
	
}
