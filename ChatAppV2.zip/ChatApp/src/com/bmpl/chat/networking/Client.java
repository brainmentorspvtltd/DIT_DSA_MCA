package com.bmpl.chat.networking;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.swing.JTextArea;

import static com.bmpl.chat.utils.Utilities.getValue;

public class Client {
	Socket socket;
	OutputStream os;
	InputStream in;
	JTextArea textArea;
	ClientWorker worker;
	
//	public Client() throws UnknownHostException, IOException {
//		int PORT = Integer.parseInt(getValue("PORT"));
//		socket = new Socket(getValue("SERVER_IP"), PORT);
//		System.out.println("Client Started...");
//		System.out.println("Enter your message : ");
//		Scanner scanner = new Scanner(System.in);
//		String message = scanner.nextLine();
//		OutputStream out = socket.getOutputStream(); 
//		out.write(message.getBytes());	// writes bytes on Network
//		System.out.println("Message sent to server...");
//		out.close();
//		socket.close();
//	}
	
	public Client(JTextArea textArea) throws UnknownHostException, IOException {
		int PORT = Integer.parseInt(getValue("PORT"));
		socket = new Socket(getValue("SERVER_IP"), PORT);
		this.textArea = textArea;
		System.out.println("Client Started...");
		os = socket.getOutputStream();
		in = socket.getInputStream();
		readMsg();
	}
	
	public void sendMsg(String msg) throws IOException {
		System.out.println("Msg : " + msg);
		os.write((msg+"\n").getBytes());
	}
	
	public void readMsg() {
		worker = new ClientWorker(in, textArea);
		worker.start();
	}
	
	
//	public static void main(String[] args) throws UnknownHostException, IOException {
//		Client client = new Client();
//	}
}
