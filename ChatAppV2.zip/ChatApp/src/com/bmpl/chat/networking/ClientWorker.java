package com.bmpl.chat.networking;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.JTextArea;

public class ClientWorker extends Thread {
	private InputStream in;
	private JTextArea textArea;
	
	public ClientWorker(InputStream in, JTextArea textArea) {
		this.in = in;
		this.textArea = textArea;
	}
	
	@Override
	public void run() {
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line;
		while(true) {
			try {
				line = br.readLine();
				if(line != null) {
					System.out.println("Line : " + line);
					textArea.setText(textArea.getText() + line);
				}
			} catch (Exception e) {
				break;
			}
//			finally {
//				try {
//					if(br != null) {
//						br.close();
//					}
//					if(in != null) {
//						in.close();
//					}
//				}
//				catch (Exception e) {
//					// TODO: handle exception
//				}
//			}
		}
	}
}
