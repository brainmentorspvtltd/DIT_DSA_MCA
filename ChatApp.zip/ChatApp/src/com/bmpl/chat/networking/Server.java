package com.bmpl.chat.networking;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

import static com.bmpl.chat.utils.Utilities.getValue;

public class Server {
	ServerSocket serverSocket;
	public Server() throws IOException {
		int PORT = Integer.parseInt(getValue("PORT"));
		serverSocket = new ServerSocket(PORT);
		System.out.println("Server started and waiting for client...");
		Socket socket = serverSocket.accept();	// accepts the client - handshaking
		System.out.println("Client Arrived");
		InputStream in = socket.getInputStream();	// read bytes from network
		byte arr[] = in.readAllBytes();
		String str = new String(arr);
		System.out.println("Client : " + str);
		in.close();
		socket.close();
	}
	public static void main(String[] args) throws IOException {
		Server server = new Server();
	}
}
