package com.bmpl.chat.networking;

//Worker = Thread
//Worker needs a job to be done
//Step 1 - create thread/worker
//Step 2 - assign a job to thread/worker
//Step 3 - thread will start doing its job
public class ServerWorker implements Runnable {

	@Override
	public void run() {
		// Logic that worker will execute
		for(int i = 1; i <= 5; i++) {
			System.out.println("I is : " + i + "," + Thread.currentThread());
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		ServerWorker job = new ServerWorker();
		Thread worker = new Thread(job);
		worker.start();
		// start method will call run() inside ServerWorker
		
		for(int i = 1; i <= 5; i++) {
			System.out.println("Main is : " + i + "," + Thread.currentThread());
		}
	}
	
}
