package com.bmpl.chat.utils;

import java.util.ResourceBundle;

public class Utilities {
	static ResourceBundle rb = ResourceBundle.getBundle("config");
	public static String getValue(String key) {
		return rb.getString(key);
	}
}
