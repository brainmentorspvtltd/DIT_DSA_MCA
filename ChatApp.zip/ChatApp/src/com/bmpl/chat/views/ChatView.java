package com.bmpl.chat.views;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;

public class ChatView {

	private JFrame frame;
	private JTextField textField;
	
	public ChatView() {
		frame = new JFrame();
		frame.setBounds(100, 100, 945, 614);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 24));
		textArea.setBounds(10, 11, 900, 447);
		frame.getContentPane().add(textArea);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 28));
		textField.setBounds(10, 469, 668, 75);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Send Message");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
		btnNewButton.setBounds(696, 469, 214, 75);
		frame.getContentPane().add(btnNewButton);
	}

	public static void main(String[] args) {
		ChatView window = new ChatView();
		window.frame.setVisible(true);
	}
}
