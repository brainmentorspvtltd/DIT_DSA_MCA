package com.skillrisers.streetfighter.sprites;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.skillrisers.streetfighter.utils.Constants;

public class Ken extends CommonPlayer implements Constants {
	
	private BufferedImage idleImages[] = new BufferedImage[4];
	private BufferedImage kickImages[] = new BufferedImage[5];
	
	public Ken() throws IOException {
		x = SCREENWDITH - 400;
		w = 200;
		h = 250;
		y = SCREENHEIGHT - h - 100;
		speed = 0;
		playerImg = ImageIO.read(Ryu.class.getResource(KEN_IMAGE));
		loadIdleImages();
		loadKickImages();
	}
	
//	private void loadPlayer() throws IOException {
//		playerImg = ImageIO.read(Ryu.class.getResource(KEN_IMAGE));
//		playerImg = playerImg.getSubimage(1347, 244, 114, 245);
//	}

	private void loadIdleImages() {
		idleImages[0] = playerImg.getSubimage(1347, 244, 114, 245);
		idleImages[1] = playerImg.getSubimage(1116, 240, 118, 249);
		idleImages[2] = playerImg.getSubimage(890, 242, 118, 247);
		idleImages[3] = playerImg.getSubimage(672, 242, 117, 247);
	}
	
	private void loadKickImages() {
		kickImages[0] = playerImg.getSubimage(1327, 1457, 126, 245);
		kickImages[1] = playerImg.getSubimage(1118, 1457, 131, 245);
		kickImages[2] = playerImg.getSubimage(840, 1462, 221, 240);
		kickImages[3] = playerImg.getSubimage(1118, 1457, 131, 245);
		kickImages[4] = playerImg.getSubimage(1327, 1457, 126, 245);
	}
	
	public BufferedImage printIdleImages() {
		isAttacking = false;
		if(imageIndex > 3) {
			imageIndex = 0;
		}
		BufferedImage img = idleImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	public BufferedImage printKickImages() {
		if(imageIndex > 4) {
			imageIndex = 0;
			currentMove = IDLE;
			isAttacking = false;
		}
		isAttacking = true;
		BufferedImage img = kickImages[imageIndex];
		imageIndex++;
		return img;
	}

	@Override
	public BufferedImage defaultImage() {
		if(currentMove == WALK) {
			return printIdleImages();
		}
		else if(currentMove == KICK) {
			return printKickImages();
		}
		else {
			return printIdleImages();
		}
	}
}
