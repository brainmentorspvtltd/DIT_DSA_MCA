package com.skillrisers.streetfighter.sprites;

import java.io.IOException;

import javax.imageio.ImageIO;

import com.skillrisers.streetfighter.utils.Constants;

public class Ken extends CommonPlayer implements Constants {
	public Ken() throws IOException {
		x = SCREENWDITH - 400;
		w = 200;
		h = 250;
		y = SCREENHEIGHT - h - 100;
		speed = 0;
		loadPlayer();
	}
	
	private void loadPlayer() throws IOException {
		playerImg = ImageIO.read(Ryu.class.getResource(KEN_IMAGE));
		playerImg = playerImg.getSubimage(1347, 244, 114, 245);
	}
}
